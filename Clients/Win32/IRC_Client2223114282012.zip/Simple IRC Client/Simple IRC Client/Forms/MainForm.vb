﻿' *********************************************************************
' *                                                                                                               
' * Simple Coders Team                                                                          
' * __________________________________________________________________                 
' *                                                                                                               
' * Author: ident/Sam                                                                             
' * Copyright © 2011 simplecoders.com. All rights reserved.           
' * Created: 30/01/2012                                                                           
' * Contact: support@simplecoders.com                       
' *                                                         
' * Summery: Simple IRC Client is a raw IRC starter pack designed for 
' * new programmers who are wanting an IRC Client that connects & joins
' * to an IRC server.                                                
' * __________________________________________________________________
' * 
' * Notice: Simple Coders products are freeware and can be  
' * modified, and redistributed under the terms of the GNU  
' * lesser general public license as published by the Free  
'  * Software Foundation; Version 3, 29 June 2007 or later.  
' *********************************************************************

Option Strict On

Public Class MainForm

#Region " Private Members "
    Private _mainView As MainView
#End Region

#Region " Form Events "
    Private Sub MainForm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        _mainView.Dispose()
    End Sub

    Private Sub MainForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SetConnectionInformation()
        LoadStartUpControl()
    End Sub
#End Region

#Region " Private Methods "
    Private Sub LoadStartUpControl()
        If _mainView Is Nothing Then
            _mainView = New MainView
        End If

        Me.PanelUserControlHolder.Controls.Add(_mainView)
    End Sub

    ''' <summary>
    ''' Sets the connection information.
    ''' </summary>
    ''' <remarks>
    ''' I added the connectionInformation module to demonstrate how i prefer to remember
    ''' server information while the application is running. Once set allows me to quickly
    ''' retrieve information avoiding the need to access My.settings or the registry.
    ''' </remarks>
    Private m_rng As New Random
    Private Sub SetConnectionInformation()
        ' Need help? Join this server & channel.
        ConnectionInformation.Server = "irc.geekshed.net"
        ConnectionInformation.Channel = "#test"
        ConnectionInformation.ChannelNick = "BattleBot_" & m_rng.Next(0, 999)
        ConnectionInformation.ChannelAltNick = "ident_" & m_rng.Next(0, 999)
        ConnectionInformation.UserName = "ident"
        ConnectionInformation.RealName = "BattleBot"
    End Sub
#End Region

End Class
