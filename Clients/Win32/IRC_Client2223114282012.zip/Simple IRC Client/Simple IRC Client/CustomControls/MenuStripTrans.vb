﻿' *********************************************************************
' *                                                                                                               
' * Simple Coders Team                                                                          
' * __________________________________________________________________                 
' *                                                                                                               
' * Author: ident/Sam                                                                             
' * Copyright © 2011 simplecoders.com. All rights reserved.           
' * Created: 30/01/2012                                                                           
' * Contact: support@simplecoders.com                       
' *                                                         
' * Summery: Simple IRC Client is a raw IRC starter pack designed for 
' * new programmers who are wanting an IRC Client that connects & joins
' * to an IRC server.                                                
' * __________________________________________________________________
' * 
' * Notice: Simple Coders products are freeware and can be  
' * modified, and redistributed under the terms of the GNU  
' * lesser general public license as published by the Free  
'  * Software Foundation; Version 3, 29 June 2007 or later.  
' *********************************************************************

Option Strict On

Imports System.Windows.Forms

''' <summary>
''' Creates a custom menu strip.
''' </summary>
''' <remarks>
''' Serves no real purpose other then over riding windows default color scheme.
''' </remarks>

Public Class MenuStripTrans
    Inherits MenuStrip

    Public Sub New()
        Me.BackColor = Color.Transparent
    End Sub
End Class


