Title: IRC Client (Simple IRC Client)(UPDATED)
Description: A basic IRC client that connects to a specified server and then joins a channel. Handles limited IRC events such as JOIN, PART & PRIVMSG. Demonstrates a basic understanding on how to split the server response into readable information.
 Also sends an IDENT response to the server on connecting which no other IRC example on planet source does. For any questions please contact ident@simplecoders.com
If you download somebody's work please take the time to rate the source. Constructive feed back helps the community learn.
* Now updated. Quite a few methods are more aimed at beginners so i felt i let that get sloppy. A few slight adjustments.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=8677&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
