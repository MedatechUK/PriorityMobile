﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("SetWidth")> 
<Assembly: AssemblyDescription("This cli changes the width of lines in a text file based upon a regular expression prefix of the line.")> 
<Assembly: AssemblyCompany("eMerge-IT")> 
<Assembly: AssemblyProduct("SetWidth")> 
<Assembly: AssemblyCopyright("Copyright © eMerge-IT 2010")> 
<Assembly: AssemblyTrademark("Future proof your business")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("376bab42-4e8b-490c-a8a2-47840e79bfd0")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.2")> 
<Assembly: AssemblyFileVersion("1.0.0.2")> 
