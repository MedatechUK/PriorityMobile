Public Class Settings

    Private Sub Settings_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Props.SelectedObject = New SimpleProperties()
    End Sub

End Class