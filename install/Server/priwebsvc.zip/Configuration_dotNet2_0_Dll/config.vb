Imports System.Configuration
Public Class PriorityConfig
    Inherits System.Configuration.ConfigurationSection

    Private m_cfg As Configuration

#Region " Instance methods "
    Public Sub Encript(ByVal encript As Boolean)
        If encript Then
            Me.SectionInformation.ProtectSection("DataProtectionConfigurationProvider")
        Else
            Me.SectionInformation.UnprotectSection()
        End If
        Me.Save()
    End Sub

    Public Sub Save()
        Me.SectionInformation.ForceSave = True
        m_cfg.Save(ConfigurationSaveMode.Full)
    End Sub

#End Region

#Region " Properties "

    <ConfigurationProperty("Bin95", DefaultValue:="", IsRequired:=True)> _
Public Property Bin95() As String
        Get
            Return CType(Me("Bin95"), String)
        End Get
        Set(ByVal value As String)
            Me("Bin95") = value
        End Set
    End Property

    <ConfigurationProperty("PriorityCompany", DefaultValue:="", IsRequired:=True)> _
    Public Property PriorityCompany() As String
        Get
            Return CType(Me("PriorityCompany"), String)
        End Get
        Set(ByVal value As String)
            Me("PriorityCompany") = value
        End Set
    End Property

    'applicationName
    <ConfigurationProperty("PriorityUser", DefaultValue:="", IsRequired:=True)> _
    Public Property PriorityUser() As String
        Get
            Return CType(Me("PriorityUser"), String)
        End Get
        Set(ByVal value As String)
            Me("PriorityUser") = value
        End Set
    End Property

    'connectionStringName
    <ConfigurationProperty("PriorityPwd", DefaultValue:="", IsRequired:=True)> _
    Public Property PriorityPwd() As String
        Get
            Return CType(Me("PriorityPwd"), String)
        End Get
        Set(ByVal value As String)
            Me("PriorityPwd") = value
        End Set
    End Property

    <ConfigurationProperty("oneElement", IsRequired:=True)> _
    Public ReadOnly Property OneElement() As PriorityConfigElementClass
        Get
            Return DirectCast(Me("oneElement"), _
                              PriorityConfigElementClass)
        End Get
    End Property

#End Region

#Region " Shared methods "
    Private Const CS_SECTION As String = "PriorityCnf"
    Private Shared m_current As PriorityConfig

    Public Shared ReadOnly Property Current() As PriorityConfig
        Get
            If m_current Is Nothing Then
                Dim cfg As Configuration
                Dim ctx As System.Web.HttpContext = System.Web.HttpContext.Current
                If ctx Is Nothing Then
                    cfg = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None)
                Else
                    cfg = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration(ctx.Request.ApplicationPath)
                End If
                m_current = DirectCast(cfg.Sections(CS_SECTION), _
                                       PriorityConfig)
                m_current.m_cfg = cfg
            End If
            Return m_current
            'You could use this code if all that you need is to read the configuration.
            'Return DirectCast(ConfigurationManager.GetSection(CS_SECTION), _
            '                          PriorityConfig)
        End Get
    End Property

#End Region

End Class

Public Class PriorityConfigElementClass
    Inherits ConfigurationElement

    <ConfigurationProperty("anotherProperty", IsRequired:=True)> _
    Public Property AnotherProperty() As String
        Get
            Return CStr(Me("anotherProperty"))
        End Get
        Set(ByVal value As String)
            Me("anotherProperty") = value
        End Set
    End Property
End Class