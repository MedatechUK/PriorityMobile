Imports System
Imports System.Collections
Imports System.Text
Imports System.Configuration
Imports System.Xml

Namespace Priority.conf

    ' see: http://msdn.microsoft.com/en-gb/library/2tw134k3.aspx

    Public Class ConfigSection
        Inherits ConfigurationSection

        <ConfigurationProperty("Bin95", DefaultValue:="", IsRequired:=True)> _
        Public Property Bin95() As String
            Get
                Return CType(Me("Bin95"), String)
            End Get
            Set(ByVal value As String)
                Me("Bin95") = value
            End Set
        End Property

        <ConfigurationProperty("PriorityCompany", DefaultValue:="", IsRequired:=True)> _
        Public Property PriorityCompany() As String
            Get
                Return CType(Me("PriorityCompany"), String)
            End Get
            Set(ByVal value As String)
                Me("PriorityCompany") = value
            End Set
        End Property

        'applicationName
        <ConfigurationProperty("PriorityUser", DefaultValue:="", IsRequired:=True)> _
        Public Property PriorityUser() As String
            Get
                Return CType(Me("PriorityUser"), String)
            End Get
            Set(ByVal value As String)
                Me("PriorityUser") = value
            End Set
        End Property

        'connectionStringName
        <ConfigurationProperty("PriorityPwd", DefaultValue:="", IsRequired:=True)> _
        Public Property PriorityPwd() As String
            Get
                Return CType(Me("PriorityPwd"), String)
            End Get
            Set(ByVal value As String)
                Me("PriorityPwd") = value
            End Set
        End Property

    End Class


End Namespace