﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("cumulocityCli")> 
<Assembly: AssemblyDescription("Cli Test tool")> 
<Assembly: AssemblyCompany("eMerge-IT")> 
<Assembly: AssemblyProduct("cumulocityCli")> 
<Assembly: AssemblyCopyright("Copyright ©eMerge-IT  2013")> 
<Assembly: AssemblyTrademark("Future proof your business.")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("c2b05701-70c8-404f-9865-c46bfb2b0779")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
