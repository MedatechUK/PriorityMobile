using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.IO;
using System.Net;
using System.xml;
using System.Security.Cryptography;

#region "World First Types"

#region "Enumerative types"

public enum w1st_enum_Side
{
	B,
	S
}

public enum w1st_enum_Reason
{
	Emigration = 1,
	Overseas_Mortgage_Payments = 3,
	Sending_Money_Home = 4,
	Transfer_to_Own_Account = 5,
	Other = 6,
	Paying_Overseas_Suppliers = 7,
	Repatriating_Overseas_Earnings = 8,
	Investing_Abroad = 9,
	Holiday_Home_Second_Home_Purchase = 16,
	Investment_Property_Purchase = 17,
	Overseas_Purchase = 18,
	Property_Sale = 19,
	Returning_From_Abroad = 20
}

#endregion

#region "Request types"

public class w1st_REQUEST_Beneficiary
{

	#region "initialisation"
	public w1st_REQUEST_Beneficiary() : base()
	{
	}
	public w1st_REQUEST_Beneficiary(string accholder, string accholderadd1, string curr, string bankname, string bankcode = null, string accno = null, string iban = null, string bic = null, string accholderadd2 = null, string accholderadd3 = null,

	string bankadd1 = null, string bankadd2 = null, string bankadd3 = null, string bankcountry = null)
	{
		var _with1 = this;
		_with1.accholder = accholder;
		_with1.accholderadd1 = accholderadd1;
		_with1.accholderadd2 = accholderadd2;
		_with1.accholderadd3 = accholderadd3;
		_with1.curr = curr;
		_with1.bankname = bankname;
		_with1.bankcode = bankcode;
		_with1.accno = accno;
		_with1.bankadd1 = bankadd1;
		_with1.bankadd2 = bankadd2;
		_with1.bankadd3 = bankadd3;
		_with1.bankcountry = bankcountry;
		_with1.iban = iban;
		_with1.bic = bic;
	}
	#endregion

	#region "Properties"
	private string _accholder = null;
	public string accholder {
		get { return _accholder; }
		set { _accholder = value; }
	}
	private string _accholderadd1 = null;
	public string accholderadd1 {
		get { return _accholderadd1; }
		set { _accholderadd1 = value; }
	}
	private string _accholderadd2 = null;
	public string accholderadd2 {
		get { return _accholderadd2; }
		set { _accholderadd2 = value; }
	}
	private string _accholderadd3 = null;
	public string accholderadd3 {
		get { return _accholderadd3; }
		set { _accholderadd3 = value; }
	}
	private string _curr = null;
	public string curr {
		get { return _curr; }
		set { _curr = value; }
	}
	private string _bankname = null;
	public string bankname {
		get { return _bankname; }
		set { _bankname = value; }
	}
	private string _bankcode = null;
	public string bankcode {
		get { return _bankcode; }
		set { _bankcode = value; }
	}
	private string _accno = null;
	public string accno {
		get { return _accno; }
		set { _accno = value; }
	}
	private string _bankadd1 = null;
	public string bankadd1 {
		get { return _bankadd1; }
		set { _bankadd1 = value; }
	}
	private string _bankadd2 = null;
	public string bankadd2 {
		get { return _bankadd2; }
		set { _bankadd2 = value; }
	}
	private string _bankadd3 = null;
	public string bankadd3 {
		get { return _bankadd3; }
		set { _bankadd3 = value; }
	}
	private string _bankcountry = null;
	public string bankcountry {
		get { return _bankcountry; }
		set { _bankcountry = value; }
	}
	private string _iban = null;
	public string iban {
		get { return _iban; }
		set { _iban = value; }
	}
	private string _bic = null;
	public string bic {
		get { return _bic; }
		set { _bic = value; }
	}
	#endregion

}

public class w1st_REQUEST_GetQuote
{

	#region "Initialisation"
	public w1st_REQUEST_GetQuote() : base()
	{
	}
	public w1st_REQUEST_GetQuote(System.DateTime SettlementDate, string BuyCurr, string SellCurr, w1st_enum_Side Side, decimal Amount)
	{
		var _with2 = this;
		_with2.SettlementDate = SettlementDate;
		_with2.BuyCurr = BuyCurr;
		_with2.SellCurr = SellCurr;
		_with2.Side = Side;
		_with2.Amount = Amount;
	}
	#endregion

	#region "Properies"
	private System.DateTime _settlementdate = DateAndTime.Now;
	public System.DateTime SettlementDate {
		get { return _settlementdate; }
		set { _settlementdate = value; }
	}
	private string _buycurr = null;
	public string BuyCurr {
		get { return _buycurr; }
		set { _buycurr = value; }
	}
	private string _sellcurr = null;
	public string SellCurr {
		get { return _sellcurr; }
		set { _sellcurr = value; }
	}
	private w1st_enum_Side _side = null;
	public w1st_enum_Side Side {
		get { return _side; }
		set { _side = value; }
	}
	private decimal _amount = null;
	public decimal Amount {
		get { return _amount; }
		set { _amount = value; }
	}
	#endregion

}

public class w1st_REQUEST_Payment
{

	#region "Initialisation"
	public w1st_REQUEST_Payment()
	{
		_tradeid = System.Guid.NewGuid().ToString();
	}
	public w1st_REQUEST_Payment(w1st_REQUEST_Beneficiary Beneficiary, string paymentid, decimal amount, System.DateTime paymentdate, string paymenttype, w1st_enum_Reason reason, string sellcurrency = null, string reason_if_other = null, string notes1 = null, string notes2 = null,

	string notes3 = null)
	{
		_tradeid = System.Guid.NewGuid().ToString();
		var _with3 = this;
		_with3.PaymentID = paymentid;
		_with3.sellcurrency = sellcurrency;
		_with3.amount = amount;
		_with3.paymentdate = paymentdate;
		_with3.paymenttype = paymenttype;
		_with3.notes1 = notes1;
		_with3.notes2 = notes2;
		_with3.notes3 = notes3;
		_with3.reason = reason;
		_with3.reason_if_other = reason_if_other;
		_with3.beneficiary = Beneficiary;
	}
	#endregion

	#region "Properties"
	private string _tradeid = "";
	public string TradeID {
		get { return _tradeid; }
	}
	private string _paymentid = null;
	public string PaymentID {
		get { return _paymentid; }
		set { _paymentid = value; }
	}
	private string _sellcurrency = null;
	public string sellcurrency {
		get { return _sellcurrency; }
		set { _sellcurrency = value; }
	}
	private decimal _amount = null;
	public decimal amount {
		get { return _amount; }
		set { _amount = value; }
	}
	private System.DateTime _paymentdate = null;
	public System.DateTime paymentdate {
		get { return _paymentdate; }
		set { _paymentdate = value; }
	}
	private string _paymenttype = null;
	public string paymenttype {
		get { return _paymenttype; }
		set { _paymenttype = value; }
	}
	private string _notes1 = null;
	public string notes1 {
		get { return _notes1; }
		set { _notes1 = value; }
	}
	private string _notes2 = null;
	public string notes2 {
		get { return _notes2; }
		set { _notes2 = value; }
	}
	private string _notes3 = null;
	public string notes3 {
		get { return _notes3; }
		set { _notes3 = value; }
	}
	private w1st_enum_Reason _reason = null;
	public w1st_enum_Reason reason {
		get { return _reason; }
		set { _reason = value; }
	}
	private string _reason_if_other = null;
	public string reason_if_other {
		get { return _reason_if_other; }
		set { _reason_if_other = value; }
	}
	private w1st_REQUEST_Beneficiary _beneficiary = new w1st_REQUEST_Beneficiary();
	public w1st_REQUEST_Beneficiary beneficiary {
		get { return _beneficiary; }
		set { _beneficiary = value; }
	}
	#endregion

}

public class w1st_REQUEST
{

	#region "Initialisation"
	public w1st_REQUEST() : base()
	{
	}
	public w1st_REQUEST(bool Atomic, bool Testing, string PastPaymentid = null)
	{
		var _with4 = this;
		_with4.Atomic = Atomic;
		_with4.Testing = Testing;
		if ((PastPaymentid != null))
			_with4.PastPaymentid = PastPaymentid;
	}
	#endregion

	#region "Properties"
	private bool _atomic = false;
	public bool Atomic {
		get { return _atomic; }
		set { _atomic = value; }
	}
	private bool _testing = false;
	public bool Testing {
		get { return _testing; }
		set { _testing = value; }
	}
	private string _pastpaymentid;
	public string PastPaymentid {
		get { return _pastpaymentid; }
		set { _pastpaymentid = value; }
	}
	#endregion

	#region "Object Dictionaries"
	private Dictionary<int, w1st_REQUEST_GetQuote> _getquote = new Dictionary<int, w1st_REQUEST_GetQuote>();
	public Dictionary<int, w1st_REQUEST_GetQuote> GetQuote {
		get { return _getquote; }
		set { _getquote = value; }
	}
	private Dictionary<int, w1st_REQUEST_Payment> _payment = new Dictionary<int, w1st_REQUEST_Payment>();
	public Dictionary<int, w1st_REQUEST_Payment> Payment {
		get { return _payment; }
		set { _payment = value; }
	}
	#endregion

}

#endregion

#region "Response Types"

public class w1st_RESPONSE_PastPayment
{

	#region "Properties"
	private string _requested_paymentid;
	public string requested_paymentid {
		get { return _requested_paymentid; }
		set { _requested_paymentid = value; }
	}
	private bool _success;
	public bool success {
		get { return _success; }
		set { _success = value; }
	}
	private System.DateTime _created;
	public System.DateTime created {
		get { return _created; }
		set { _created = value; }
	}
	private string _tradeid;
	public string tradeid {
		get { return _tradeid; }
		set { _tradeid = value; }
	}
	private string _buycurr;
	public string buycurr {
		get { return _buycurr; }
		set { _buycurr = value; }
	}
	private string _sellcurr;
	public string sellcurr {
		get { return _sellcurr; }
		set { _sellcurr = value; }
	}
	private string _amount;
	public string amount {
		get { return _amount; }
		set { _amount = value; }
	}
	private string _rate;
	public string rate {
		get { return _rate; }
		set { _rate = value; }
	}
	private System.DateTime _paymentdate;
	public System.DateTime paymentdate {
		get { return _paymentdate; }
		set { _paymentdate = value; }
	}
	#endregion

	#region "Dictionaries"
	private Dictionary<int, w1st_RESPONSE_error> _errors = new Dictionary<int, w1st_RESPONSE_error>();
	public Dictionary<int, w1st_RESPONSE_error> Errors {
		get { return _errors; }
		set { _errors = value; }
	}
	#endregion

}

public class w1st_RESPONSE_payment
{

	#region "Properties"

	private bool _success;
	public bool success {
		get { return _success; }
		set { _success = value; }
	}
	private string _tradeid;
	public string tradeid {
		get { return _tradeid; }
		set { _tradeid = value; }
	}
	private string _paymentid;
	public string paymentid {
		get { return _paymentid; }
		set { _paymentid = value; }
	}
	private string _buycurr;
	public string buycurr {
		get { return _buycurr; }
		set { _buycurr = value; }
	}
	private string _sellcurr;
	public string sellcurr {
		get { return _sellcurr; }
		set { _sellcurr = value; }
	}
	private decimal _amount;
	public decimal amount {
		get { return _amount; }
		set { _amount = value; }
	}
	private string _rate;
	public string rate {
		get { return _rate; }
		set { _rate = value; }
	}
	private System.DateTime _paymentdate;
	public System.DateTime paymentdate {
		get { return _paymentdate; }
		set { _paymentdate = value; }
	}
	#endregion

	#region "Dictionaries"
	private Dictionary<int, w1st_RESPONSE_error> _errors = new Dictionary<int, w1st_RESPONSE_error>();
	public Dictionary<int, w1st_RESPONSE_error> Errors {
		get { return _errors; }
		set { _errors = value; }
	}
	#endregion

}

public class w1st_RESPONSE_quote
{

	#region "Properties"

	private bool _success;
	public bool success {
		get { return _success; }
		set { _success = value; }
	}
	private string _tradeid;
	public string tradeid {
		get { return _tradeid; }
		set { _tradeid = value; }
	}
	private string _buycurr;
	public string buycurr {
		get { return _buycurr; }
		set { _buycurr = value; }
	}
	private string _sellcurr;
	public string sellcurr {
		get { return _sellcurr; }
		set { _sellcurr = value; }
	}
	private decimal _buyamt;
	public decimal buyamt {
		get { return _buyamt; }
		set { _buyamt = value; }
	}
	private decimal _sellamt;
	public decimal sellamt {
		get { return _sellamt; }
		set { _sellamt = value; }
	}
	private string _rate;
	public string rate {
		get { return _rate; }
		set { _rate = value; }
	}
	private System.DateTime _settlementdate;
	public System.DateTime settlementdate {
		get { return _settlementdate; }
		set { _settlementdate = value; }
	}
	private string _expiry;
	public string expiry {
		get { return _expiry; }
		set { _expiry = value; }
	}
	private w1st_enum_Side _side;
	public w1st_enum_Side side {
		get { return _side; }
		set { _side = value; }
	}
	private string _amount;
	public string amount {
		get { return _amount; }
		set { _amount = value; }
	}
	#endregion

	#region "Dictionaries"
	private Dictionary<int, w1st_RESPONSE_error> _errors = new Dictionary<int, w1st_RESPONSE_error>();
	public Dictionary<int, w1st_RESPONSE_error> Errors {
		get { return _errors; }
		set { _errors = value; }
	}
	#endregion

}

public class w1st_RESPONSE_error
{

	#region "Initialisation"
	public w1st_RESPONSE_error() : base()
	{
	}

	public w1st_RESPONSE_error(string Code, string Message)
	{
		var _with5 = this;
		_with5.code = Code;
		_with5.message = Message;
	}
	#endregion

	#region "Properties"

	private string _code = null;
	public string code {
		get { return _code; }
		set { _code = value; }
	}
	private string _message = null;
	public string message {
		get { return _message; }
		set { _message = value; }
	}
	#endregion

}

public class w1st_RESPONSE
{

	#region "Initialisation"

	public w1st_RESPONSE() : base()
	{
	}

	public w1st_RESPONSE(bool Atomic, bool Testing)
	{
		var _with6 = this;
		_with6.Atomic = Atomic;
		_with6.Testing = Testing;
	}

	#endregion

	#region "Properties"
	private bool _atomic = false;
	public bool Atomic {
		get { return _atomic; }
		set { _atomic = value; }
	}
	private bool _testing = false;
	public bool Testing {
		get { return _testing; }
		set { _testing = value; }
	}
	#endregion

	#region "Object Dictionaries"
	private Dictionary<int, w1st_RESPONSE_error> _errors = new Dictionary<int, w1st_RESPONSE_error>();
	public Dictionary<int, w1st_RESPONSE_error> Errors {
		get { return _errors; }
		set { _errors = value; }
	}
	private Dictionary<int, w1st_RESPONSE_payment> _payment = new Dictionary<int, w1st_RESPONSE_payment>();
	public Dictionary<int, w1st_RESPONSE_payment> Payment {
		get { return _payment; }
		set { _payment = value; }
	}
	private Dictionary<int, w1st_RESPONSE_quote> _quote = new Dictionary<int, w1st_RESPONSE_quote>();
	public Dictionary<int, w1st_RESPONSE_quote> Quote {
		get { return _quote; }
		set { _quote = value; }
	}
	private Dictionary<int, w1st_RESPONSE_PastPayment> _pastpayment = new Dictionary<int, w1st_RESPONSE_PastPayment>();
	public Dictionary<int, w1st_RESPONSE_PastPayment> PastPayment {
		get { return _pastpayment; }
		set { _pastpayment = value; }
	}
	#endregion

}

#endregion

#endregion

#region "World First API"

public class w1st_Service
{

	#region "Initialisation"
	public w1st_Service() : base()
	{
	}
	public w1st_Service(string url, string user, string pass, string key, Encoding enc = null)
	{
		var _with7 = this;
		_with7.user = user;
		_with7.pass = pass;
		_with7.key = key;
		if ((enc != null))
			_with7.enc = enc;
	}
	#endregion

	#region "Properties"
	private string _url = "https://trading.worldfirst.com/api/demo/";
	public string url {
		get { return _url + "?hash=" + Hash; }
		set { _url = value; }
	}
	private string _user = "demo";
	public string user {
		get { return _user; }
		set { _user = value; }
	}
	private string _pass = "d3m0u5r";
	public string pass {
		get { return _pass; }
		set { _pass = value; }
	}
	private string _key = "abcdefghihjklmnopqrstuvwxyz0123456789";
	public string key {
		get { return _key; }
		set { _key = value; }
	}
	private Encoding _enc = Encoding.UTF8;
	public Encoding enc {
		get { return _enc; }
		set { _enc = value; }
	}
	private w1st_REQUEST _request;
	public w1st_REQUEST request {
		get { return _request; }
		set { _request = value; }
	}
	private w1st_RESPONSE _repsonse;
	public w1st_RESPONSE response {
		get { return _repsonse; }
		set { _repsonse = value; }
	}
	public string RequestXML {
		get {
			string xml = "";
			var _with8 = this.request;

			xml += "<request>";
			xml += string.Format("<atomic>{0}</atomic>", Strings.LCase(Convert.ToString(_with8.Atomic)));
			xml += string.Format("<testing>{0}</testing>", Strings.LCase(Convert.ToString(_with8.Testing)));
			if ((_with8.PastPaymentid != null))
				xml += string.Format("<PastPaymentid>{0}</PastPaymentid>", _with8.PastPaymentid);

			if (_with8.GetQuote.Count > 0) {
				foreach (w1st_REQUEST_GetQuote q in _with8.GetQuote.Values) {
					xml += "<getquote>";
					var _with9 = q;
					xml += string.Format("<settlementdate>{0}-{1}-{2}</settlementdate>", DateAndTime.Year(_with9.SettlementDate), Strings.Right("00" + Convert.ToString(DateAndTime.Month(_with9.SettlementDate)), 2), Strings.Right("00" + Convert.ToString(DateAndTime.Day(_with9.SettlementDate)), 2));
					xml += string.Format("<buycurr>{0}</buycurr>", _with9.BuyCurr);
					xml += string.Format("<sellcurr>{0}</sellcurr>", _with9.SellCurr);
					switch (_with9.Side) {
						case w1st_enum_Side.B:
							xml += string.Format("<side>{0}</side>", "B");
							break;
						case w1st_enum_Side.S:
							xml += string.Format("<side>{0}</side>", "S");
							break;
					}
					xml += string.Format("<amount>{0}</amount>", _with9.Amount);
					xml += "</getquote>";
				}
			}

			if (_with8.Payment.Count > 0) {
				foreach (w1st_REQUEST_Payment p in _with8.Payment.Values) {
					xml += "<payment>";
					var _with10 = p;
					xml += string.Format("<tradeid>{0}</tradeid>", _with10.TradeID);
					xml += string.Format("<paymentid>{0}</paymentid>", _with10.PaymentID);
					if ((_with10.sellcurrency != null))
						xml += string.Format("<sellcurrency>{0}</sellcurrency>", _with10.sellcurrency);
					xml += string.Format("<amount>{0}</amount>", _with10.amount);
					xml += string.Format("<paymentdate>{0}-{1}-{2}</paymentdate>", DateAndTime.Year(_with10.paymentdate), Strings.Right("00" + Convert.ToString(DateAndTime.Month(_with10.paymentdate)), 2), Strings.Right("00" + Convert.ToString(DateAndTime.Day(_with10.paymentdate)), 2));
					xml += string.Format("<paymenttype>{0}</paymenttype>", _with10.paymenttype);
					if ((_with10.notes1 != null))
						xml += string.Format("<notes1>{0}</notes1>", _with10.notes1);
					if ((_with10.notes2 != null))
						xml += string.Format("<notes2>{0}</notes2>", _with10.notes2);
					if ((_with10.notes3 != null))
						xml += string.Format("<notes3>{0}</notes3>", _with10.notes3);
					xml += string.Format("<reason>{0}</reason>", Convert.ToString(Convert.ToInt32(_with10.reason)));
					if ((_with10.reason_if_other != null))
						xml += string.Format("<reason_if_other>{0}</reason_if_other>", _with10.reason_if_other);

					xml += "<beneficiary>";
					var _with11 = _with10.beneficiary;
					xml += string.Format("<accholder>{0}</accholder>", _with11.accholder);
					xml += string.Format("<accholderadd1>{0}</accholderadd1>", _with11.accholderadd1);
					if ((_with11.accholderadd2 != null))
						xml += string.Format("<accholderadd2>{0}</accholderadd2>", _with11.accholderadd2);
					if ((_with11.accholderadd3 != null))
						xml += string.Format("<accholderadd3>{0}</accholderadd3>", _with11.accholderadd3);
					xml += string.Format("<curr>{0}</curr>", _with11.curr);
					xml += string.Format("<bankname>{0}</bankname>", _with11.bankname);
					if ((_with11.bankcode != null))
						xml += string.Format("<bankcode>{0}</bankcode>", _with11.bankcode);
					if ((_with11.accno != null))
						xml += string.Format("<accno>{0}</accno>", _with11.accno);
					if ((_with11.bankadd1 != null))
						xml += string.Format("<bankadd1>{0}</bankadd1>", _with11.bankadd1);
					if ((_with11.bankadd2 != null))
						xml += string.Format("<bankadd2>{0}</bankadd2>", _with11.bankadd2);
					if ((_with11.bankadd3 != null))
						xml += string.Format("<bankadd3>{0}</bankadd3>", _with11.bankadd3);
					if ((_with11.bankcountry != null))
						xml += string.Format("<bankcountry>{0}</bankcountry>", _with11.bankcountry);
					if ((_with11.iban != null))
						xml += string.Format("<iban>{0}</iban>", _with11.iban);
					if ((_with11.bic != null))
						xml += string.Format("<bic>{0}</bic>", _with11.bic);
					xml += "</beneficiary>";
					xml += "</payment>";
				}
			}

			xml += "</request>";
			return xml;
		}
	}
	public string Hash {
		get {
			byte[] bKey = _enc.GetBytes(key);
			byte[] bMessage = _enc.GetBytes(RequestXML);
			HMACMD5 hmacmd5 = new HMACMD5(bKey);
			MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
			byte[] md5Hash = parseHash(md5.ComputeHash(bMessage));
			string smd5Hash = _enc.GetString(md5Hash);
			byte[] bMsgHash = parseHash(hmacmd5.ComputeHash(md5Hash));
			return _enc.GetString(bMsgHash);
		}
	}
	#endregion

	#region "public functions"


	public void Send()
	{
		WebRequest webRequest = System.Net.WebRequest.Create(url);

		var _with12 = webRequest;
		_with12.Credentials = new NetworkCredential(user, pass);
		_with12.ContentType = "application/x-www-form-urlencoded";
		_with12.Method = "POST";

		byte[] bytes = _enc.GetBytes(RequestXML);
		Stream os = null;
		try {
			webRequest.ContentLength = bytes.Length;
			os = webRequest.GetRequestStream();
			os.Write(bytes, 0, bytes.Length);
		} catch (WebException ex) {
			throw new Exception("HttpPost: Request error - " + ex.Message);
		} finally {
			if ((os != null)) {
				os.Close();
			}
		}

		try {
			XmlDocument xd = new XmlDocument();
			WebResponse webResponse = webRequest.GetResponse();
			if ((WebResponse != null)) {
				using (StreamReader sr = new StreamReader(webResponse.GetResponseStream())) {
					xd.LoadXml(sr.ReadToEnd().Trim());
					parseResponse(xd);
				}
			} else {
				throw new Exception("HttpPost: Response error - returned null.");
			}
		} catch (WebException ex) {
			throw new Exception("HttpPost: Response error - " + ex.Message);
		}

	}

	#endregion

	#region "Private Functions"

	private byte[] parseHash(byte[] hash)
	{

		string ret = "";
		foreach (byte a in hash) {
			ret += a.ToString("x2");
		}
		return _enc.GetBytes(ret);

	}

	private void parseResponse(XmlDocument xd)
	{
		response = null;
		response = new w1st_RESPONSE();
		var _with13 = response;
		foreach (XmlNode n in xd.ChildNodes) {
			switch (Strings.LCase(n.Name)) {
				case "response":
					foreach (XmlNode no in n.ChildNodes) {
						switch (Strings.LCase(no.Name)) {
							case "atomic":
								_with13.Atomic = Convert.ToBoolean(no.InnerText);
								break;
							case "testing":
								_with13.Testing = Convert.ToBoolean(no.InnerText);
								break;
							case "error":
								var _with14 = _with13.Errors;
								_with14.Add(_with14.Count + 1, parseError(no));
								break;
							case "quote":
								var _with15 = _with13.Quote;
								_with15.Add(_with15.Count + 1, parseQuote(no));
								break;
							case "payment":
								var _with16 = _with13.Payment;
								_with16.Add(_with16.Count + 1, parsePayment(no));
								break;
							case "past-payment":
								var _with17 = _with13.PastPayment;
								_with17.Add(_with17.Count + 1, parsePastPayment(no));
								break;
						}
					}

					break;
			}
		}
	}

	private w1st_RESPONSE_error parseError(XmlNode node)
	{
		w1st_RESPONSE_error ret = new w1st_RESPONSE_error();
		var _with18 = ret;
		foreach (XmlNode no in node.ChildNodes) {
			switch (Strings.LCase(no.Name)) {
				case "code":
					_with18.code = no.InnerText;
					break;
				case "message":
					_with18.message = no.InnerText;
					break;
			}
		}
		return ret;
	}

	private w1st_RESPONSE_quote parseQuote(XmlNode node)
	{
		w1st_RESPONSE_quote ret = new w1st_RESPONSE_quote();
		var _with19 = ret;
		foreach (XmlNode no in node.ChildNodes) {
			switch (Strings.LCase(no.Name)) {
				case "success":
					_with19.success = Convert.ToBoolean(no.InnerText);
					break;
				case "tradeid":
					_with19.tradeid = no.InnerText;
					break;
				case "buycurr":
					_with19.buycurr = no.InnerText;
					break;
				case "sellcurr":
					_with19.sellcurr = no.InnerText;
					break;
				case "buyamt":
					_with19.buyamt = Convert.ToDouble(no.InnerText);
					break;
				case "sellamt":
					_with19.sellamt = Convert.ToDouble(no.InnerText);
					break;
				case "rate":
					_with19.rate = no.InnerText;
					break;
				case "settlementdate":
					_with19.settlementdate = DateTime.ParseExact(no.InnerText, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat);
					break;
				case "expiry":
					_with19.expiry = no.InnerText;
					break;
				case "side":
					switch (Strings.UCase(no.InnerText)) {
						case "B":
							_with19.side = w1st_enum_Side.B;
							break;
						case "S":
							_with19.side = w1st_enum_Side.S;
							break;
					}
					break;
				case "amount":
					_with19.amount = no.InnerText;
					break;
				case "error":
					var _with20 = _with19.Errors;
					_with20.Add(_with20.Count + 1, parseError(no));
					break;
			}
		}
		return ret;
	}

	private w1st_RESPONSE_payment parsePayment(XmlNode node)
	{
		w1st_RESPONSE_payment ret = new w1st_RESPONSE_payment();
		var _with21 = ret;
		foreach (XmlNode no in node.ChildNodes) {
			switch (Strings.LCase(no.Name)) {
				case "success":
					_with21.success = Convert.ToBoolean(no.InnerText);
					break;
				case "tradeid":
					_with21.tradeid = no.InnerText;
					break;
				case "paymentid":
					_with21.paymentid = no.InnerText;
					break;
				case "buycurr":
					_with21.buycurr = no.InnerText;
					break;
				case "sellcurr":
					_with21.sellcurr = no.InnerText;
					break;
				case "amount":
					_with21.amount = Convert.ToDouble(no.InnerText);
					break;
				case "rate":
					_with21.rate = no.InnerText;
					break;
				case "paymentdate":
					_with21.paymentdate = DateTime.ParseExact(no.InnerText, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat);
					break;
				case "error":
					var _with22 = _with21.Errors;
					_with22.Add(_with22.Count + 1, parseError(no));
					break;
			}
		}
		return ret;
	}

	private w1st_RESPONSE_PastPayment parsePastPayment(XmlNode node)
	{
		w1st_RESPONSE_PastPayment ret = new w1st_RESPONSE_PastPayment();
		var _with23 = ret;
		foreach (XmlNode no in node.ChildNodes) {
			switch (Strings.LCase(no.Name)) {
				case "requested-paymentid":
					_with23.requested_paymentid = no.InnerText;
					break;
				case "success":
					_with23.success = Convert.ToBoolean(no.InnerText);
					break;
				case "created":
					_with23.created = DateTime.ParseExact(no.InnerText, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat);
					break;
				case "tradeid":
					_with23.requested_paymentid = no.InnerText;
					break;
				case "buycurr":
					_with23.requested_paymentid = no.InnerText;
					break;
				case "sellcurr":
					_with23.requested_paymentid = no.InnerText;
					break;
				case "amount":
					_with23.requested_paymentid = Convert.ToDouble(no.InnerText);
					break;
				case "rate":
					_with23.requested_paymentid = no.InnerText;
					break;
				case "paymentdate":
					_with23.requested_paymentid = DateTime.ParseExact(no.InnerText, "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat);
					break;
				case "error":
					var _with24 = _with23.Errors;
					_with24.Add(_with24.Count + 1, parseError(no));
					break;
			}
		}
		return ret;
	}

	#endregion

}

#endregion