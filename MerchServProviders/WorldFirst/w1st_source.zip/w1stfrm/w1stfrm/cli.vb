Imports System.Text.RegularExpressions
Imports System.Threading
Imports System.Reflection
Imports System.io
Imports ConsoleApp
Imports w1st
Imports Loading

Module cli

    Enum myRunMode As Integer
        Normal = 0
        Config = 1
        Rate = 2
    End Enum

    Dim WithEvents cApp As New ConsoleApp.CA
    Dim ws As New PriWebSVC.Service
    Dim w1svc As w1st_Service

    Private PAYDATE As Date = Nothing
    Private SUP As Integer = Nothing
    Private Env As String = ""
    Private IVNum As String = Nothing
    Private quiet As Boolean = False
    Private testing As Boolean = False
    Private hasErrors As Boolean = False
    Private CurStr As String = Nothing
    Private Pause As Integer = 0

    Private PR As New Dictionary(Of String, PayRef)

#Region "Console Subs"

    Sub Main()

        With cApp
            .Quit = False
            .RunMode = myRunMode.Normal
            .doWelcome(Assembly.GetExecutingAssembly())
            Try
                .GetArgs(Command)
            Catch ex As Exception
                Console.WriteLine(ex.Message)
            End Try

            If Not .Quit Then
                Select Case .RunMode
                    Case myRunMode.Normal
                        If Not quiet Then Console.WriteLine("Run Mode = Normal")
                        If Not IsNothing(IVNum) Then
                            GetPriorityData()
                        Else
                            Console.Write("Invoice number is invalid")
                        End If
                    Case myRunMode.Rate
                        If Not quiet Then Console.WriteLine("Run Mode = Rate")
                        If Not IsNothing(CurStr) Then
                            GetRate()
                        Else
                            Console.Write("Currency is invalid")
                        End If
                    Case myRunMode.Config

                End Select
            End If

            cApp.Finalize()

        End With
    End Sub

    Private Sub cApp_Switch(ByVal StrVal As String, ByRef State As String, ByRef Valid As Boolean) Handles cApp.Switch
        Try
            With cApp
                Select Case lcase(StrVal)
                    Case "config"
                        .RunMode = myRunMode.Config
                        State = Nothing
                    Case "r", "rate"
                        .RunMode = myRunMode.Rate
                        State = Nothing
                    Case "c", "cur", "curr", "currency"
                        state = "c"
                    Case "i", "iv", "ivnum"
                        State = "i"
                    Case "e", "env"
                        State = "e"
                    Case "p", "pause"
                        State = "p"
                    Case "t", "testing"
                        testing = True
                    Case "q"
                        quiet = True
                    Case Else
                        Valid = False
                End Select
            End With
        Catch ex As Exception
            Console.Write(ex.Message)
        End Try
    End Sub

    Private Sub cApp_SwitchVar(ByVal State As String, ByVal StrVal As String, ByRef Valid As Boolean) Handles cApp.SwitchVar
        Try
            With cApp
                Select Case State
                    Case "i"
                        IVNum = StrVal.ToUpper
                        If Not quiet Then Console.WriteLine("IVNUM = " & IVNum)
                    Case "e"
                        Env = StrVal
                        If Not quiet Then Console.WriteLine("Environment = " & Env)
                    Case "c"
                        CurStr = StrVal.ToUpper
                        If Not quiet Then Console.WriteLine("Currency = " & CurStr)
                    Case "p"
                        Pause = CInt(StrVal)
                    Case Else
                        Valid = False
                End Select
            End With
        Catch ex As Exception
            Console.Write(ex.Message)
        End Try
    End Sub

#End Region

    Private Sub GetRate()

        Dim msg As String = Nothing

        Try

            Dim selamt As Double = Nothing
            Dim quoteID As String = Nothing
            Dim sd As New Loading.SerialData

            w1svc = initService()

            With w1svc

                '__________________________________________________Quote

                .request = New w1st_REQUEST(False, )
                With .request
                    With .GetQuote ' Request a quote
                        .Add(.Count + 1, initRateQuote)
                    End With
                End With

                If Not quiet Then
                    ' Display the request
                    Console.WriteLine("Request Quote ------------------------------------")
                    Console.WriteLine(String.Format("XML: {0}", .RequestXML))
                    Console.WriteLine(String.Format("Hash: {0}", .Hash))
                End If

                ' Send the request to popluate the response object
                .Send()

                If Not IsNothing(.response) Then

                    With .response
                        If Not quiet Then
                            Console.WriteLine("Response------------------------------------")
                            Console.WriteLine(String.Format("Atomic: {0} Testing: {1}", .Atomic))
                        End If
                        DoErrs(.Errors)

                        ' Iterate through payments in the response
                        For Each p As w1st_RESPONSE_quote In .Quote.Values
                            With p

                                DoErrs(.Errors)
                                If .success Then
                                    selamt = .rate
                                    quoteID = .tradeid
                                    If Not quiet Then
                                        Console.WriteLine( _
                                            String.Format( _
                                                "success: {0} tradeid: {1}" & _
                                                "buycurr: {2} sellcurr: {3} " & _
                                                "amount: {4} rate: {5}", _
                                                .success, _
                                                .tradeid, _
                                                .buycurr, _
                                                .sellcurr, _
                                                .amount, _
                                                .rate _
                                                ) _
                                            )
                                    End If
                                    msg = String.Format("{2}" & _
                                      "@{4}{2}" & _
                                      "{5} 1 = {0} {1}{2}" & _
                                      "{0} 1 = {5} {3}{2}", _
                                                .buycurr, _
                                                Format(CDbl(.rate), "0.00000"), _
                                                "\n", _
                                                Format((1 / CDbl(.rate)), "0.00000"), _
                                                Format(Date.Now, "dd/MM/yyyy hh:mm:ss"), _
                                                .sellcurr _
                                        )

                                End If
                            End With
                        Next
                    End With
                End If

                If hasErrors Then
                    Exit Sub
                End If

                If Not quiet Then
                    Console.Write(Replace(msg, "\n", vbCrLf))
                End If

                ws.GetData( _
                String.Format( _
                    "INSERT INTO ZEMG_W1LOADERR " & _
                    "(LINE,RECORDTYPE,IVNUM,CURDATE,CODE,MESSAGE) " & _
                    "VALUES " & _
                    "({4},'2','{0}',{1},'{2}','{3}')", _
                        CurStr, _
                        DateDiff(DateInterval.Minute, #1/1/1988#, Now).ToString(), _
                        "", _
                        msg, _
                        NextErrLine _
                    ), _
                Env _
            )

            End With

        Catch ex As Exception
            'cApp.Wait = True
            Console.WriteLine(ex.Message)
        End Try

    End Sub

    Private Sub GetPriorityData()

        Try
            Dim selcur As String = Nothing
            Dim selamt As Double = Nothing
            Dim quoteID As String = Nothing
            Dim rate As String = Nothing
            Dim msg As String = Nothing
            Dim sd As New Loading.SerialData

            w1svc = initService()

            With w1svc

                '__________________________________________________Quote

                .request = New w1st_REQUEST(False, )
                With .request
                    With .GetQuote ' Request a quote
                        .Add(.Count + 1, initQuote)
                    End With
                End With

                If Not quiet Then
                    ' Display the request
                    Console.WriteLine("Request Quote ------------------------------------")
                    Console.WriteLine(String.Format("XML: {0}", .RequestXML))
                    Console.WriteLine(String.Format("Hash: {0}", .Hash))
                End If

                ' Send the request to popluate the response object
                .Send()

                Dim pauseform As New PauseDialog

                If Not IsNothing(.response) Then

                    With .response
                        If Not quiet Then
                            Console.WriteLine("Response------------------------------------")
                            Console.WriteLine(String.Format("Atomic: {0}", .Atomic))
                        End If
                        DoErrs(.Errors)

                        ' Iterate through payments in the response
                        For Each p As w1st_RESPONSE_quote In .Quote.Values
                            With p

                                DoErrs(.Errors)

                                If .success Then
                                    If Not quiet Then
                                        Console.WriteLine( _
                                            String.Format( _
                                                "success: {0} tradeid: {1}" & _
                                                "buycurr: {2} sellcurr: {3} " & _
                                                "amount: {4} rate: {5}", _
                                                .success, _
                                                .tradeid, _
                                                .buycurr, _
                                                .sellcurr, _
                                                .amount, _
                                                .rate _
                                                ) _
                                            )
                                    End If
                                    rate = .rate
                                    selcur = .sellcurr
                                    selamt = .sellamt
                                    quoteID = .tradeid
                                    msg = String.Format("{2}" & _
                                      "@{4}{2}" & _
                                      "{5} 1 = {0} {1}{2}" & _
                                      "{0} 1 = {5} {3}{2}", _
                                                .buycurr, _
                                                Format(CDbl(.rate), "0.00000"), _
                                                vbCrLf, _
                                                Format((1 / CDbl(.rate)), "0.00000"), _
                                                Format(Date.Now, "dd/MM/yyyy hh:mm:ss"), _
                                                .sellcurr _
                                        )
                                    With pauseform
                                        .Quote = p.tradeid
                                        .rate = Format(CDbl(p.rate), "0.00000")
                                        .rrate = Format((1 / CDbl(p.rate)), "0.00000")
                                        .ratedate = Format(Date.Now, "dd/MM/yyyy hh:mm:ss")
                                        .buycur = p.buycurr
                                        .sellcur = p.sellcurr
                                        .selamt = p.sellamt
                                        .Duration = p.expiry
                                    End With
                                End If
                            End With
                        Next
                    End With
                End If

                If hasErrors Then
                    Exit Sub
                End If

                pauseform.Draw()
                If pauseform.ShowDialog() = Windows.Forms.DialogResult.Cancel Then

                    'If CancelTrade(quoteID, selcur, selamt, rate, msg) Then
                    ws.GetData( _
                    String.Format( _
                            "INSERT INTO ZEMG_W1LOADERR " & _
                            "(LINE,RECORDTYPE,IVNUM,CURDATE,CODE,MESSAGE) " & _
                            "VALUES " & _
                            "({4},'2','{0}',{1},'{2}','{3}')", _
                                IVNum.ToUpper, _
                                DateDiff(DateInterval.Minute, #1/1/1988#, Now).ToString(), _
                                "", _
                                "Trade timed-out or was cancelled by user.", _
                                NextErrLine _
                            ), _
                        Env _
                    )
                    Exit Sub
                End If

                '____________________________________Payment
                .request = New w1st_REQUEST(True, )
                With .request
                    With .Payment ' Request a payment
                        For Each payreq As w1st_REQUEST_Payment In initPayment(quoteID)
                            .Add(.Count + 1, payreq)
                        Next
                    End With
                End With

                ' Display the request
                If Not quiet Then
                    Console.WriteLine("Request Payment ------------------------------------")
                    Console.WriteLine(String.Format("XML: {0}", .RequestXML))
                    Console.WriteLine(String.Format("Hash: {0}", .Hash))
                End If

                ' Send the request to popluate the response object
                .Send()

                If Not IsNothing(.response) Then
                    With .response
                        DoConf(.tradeconfirmation)

                        If Not quiet Then
                            Console.WriteLine("Response------------------------------------")
                            Console.WriteLine(String.Format("Atomic: {0}", .Atomic))
                        End If

                        DoErrs(.Errors)

                        ' Iterate through payments in the response
                        For Each p As w1st_RESPONSE_payment In .Payment.Values
                            With p
                                PR(.paymentid).HasResponse = True

                                DoErrs(.Errors)

                                If .success Then
                                    If Not quiet Then
                                        Console.WriteLine( _
                                            String.Format( _
                                                "success: {0} tradeid: {1} paymentid: {2} " & _
                                                "buycurr: {3} sellcurr: {4} " & _
                                                "amount: {5} rate: {6} paymentdate: {7}", _
                                                .success, _
                                                .tradeid, _
                                                .paymentid, _
                                                .buycurr, _
                                                .sellcurr, _
                                                .amount, _
                                                .rate, _
                                                .paymentdate _
                                                ) _
                                            )
                                    End If

                                    PR(.paymentid).Rate = .rate
                                    PR(.paymentid).TradeID = .tradeid

                                End If
                            End With
                        Next
                    End With
                End If

                '-----------------------------
                '____________________________________Past Payment
                .request = New w1st_REQUEST(True, )
                With .request
                    With .PastPayment ' Request a payment
                        For Each k As String In PR.Keys
                            If Not PR(k).HasResponse Then
                                .Add(.Count + 1, New w1st_REQUEST_PastPayment(k))
                            End If
                        Next
                    End With
                End With

                If .request.PastPayment.Count > 0 Then

                    ' Display the request
                    If Not quiet Then
                        Console.WriteLine("Request Past Payment For missing request ------------------------------------")
                        Console.WriteLine(String.Format("XML: {0}", .RequestXML))
                        Console.WriteLine(String.Format("Hash: {0}", .Hash))
                    End If

                    ' Send the request to popluate the response object
                    .Send()

                    If Not IsNothing(.response) Then
                        With .response

                            DoConf(.tradeconfirmation)

                            If Not quiet Then
                                Console.WriteLine("Response------------------------------------")
                                Console.WriteLine(String.Format("Atomic: {0} ", .Atomic))
                            End If

                            DoErrs(.Errors)

                            ' Iterate through payments in the response
                            For Each p As w1st_RESPONSE_PastPayment In .PastPayment.Values
                                With p

                                    DoErrs(.Errors)

                                    If .success Then

                                        If Not quiet Then
                                            Console.WriteLine( _
                                                String.Format( _
                                                    "success: {0} tradeid: {1} paymentid: {2} " & _
                                                    "buycurr: {3} sellcurr: {4} " & _
                                                    "amount: {5} rate: {6} paymentdate: {7}", _
                                                    .success, _
                                                    .tradeid, _
                                                    .requested_paymentid, _
                                                    .buycurr, _
                                                    .sellcurr, _
                                                    .amount, _
                                                    .rate, _
                                                    .paymentdate _
                                                    ) _
                                                )
                                        End If

                                        PR(.requested_paymentid).Rate = .rate
                                        PR(.requested_paymentid).TradeID = .tradeid

                                    End If
                                End With
                            Next
                        End With
                    End If
                End If
            End With

            If Not hasErrors Then

                Dim r As Double = 0
                For Each k As String In PR.Keys
                    With PR(k)
                        ws.GetData( _
                            String.Format( _
                                "UPDATE FNCITEMSA SET DETAILS='{0}' WHERE FNCTRANS={1} AND KLINE={2}", _
                                .TradeID, _
                                .FNCTRANS, _
                                .KLINE _
                                ) _
                            , Env _
                        )
                        r = .Rate
                    End With
                Next

                ws.GetData( _
                    String.Format( _
                        "UPDATE INVOICES SET LEXCHANGE = {0} " & _
                        "WHERE IVNUM='{1}'", _
                         Format(1 / CDbl(r), "0.00000").ToString, _
                         IVNum.ToUpper _
                        ), _
                    Env _
                )
            End If

        Catch ex As Exception
            ws.GetData( _
                String.Format( _
                    "INSERT INTO ZEMG_W1LOADERR " & _
                    "(LINE,RECORDTYPE,IVNUM,CURDATE,CODE,MESSAGE) " & _
                    "VALUES " & _
                    "({4},'1','{0}',{1},'{2}','{3}')", _
                        IVNum.ToUpper, _
                        DateDiff(DateInterval.Minute, #1/1/1988#, Now).ToString(), _
                        ".NET", _
                        ex.Message, _
                        NextErrLine _
                    ), _
                Env _
            )
            'cApp.Wait = True
            Console.WriteLine(ex.Message)
        End Try

    End Sub

    Private Sub DoErrs(ByVal ErrorDictionary As Dictionary(Of Integer, w1st_RESPONSE_error))

        For Each er As w1st_RESPONSE_error In ErrorDictionary.Values
            hasErrors = True
            With er
                If cApp.RunMode = myRunMode.Normal Then
                    ws.GetData( _
                        String.Format( _
                            "INSERT INTO ZEMG_W1LOADERR " & _
                            "(LINE,RECORDTYPE,IVNUM,CURDATE,CODE,MESSAGE) " & _
                            "VALUES " & _
                            "({4},'1','{0}',{1},'{2}','{3}')", _
                                IVNum.ToUpper, _
                                DateDiff(DateInterval.Minute, #1/1/1988#, Now).ToString(), _
                                .code, _
                                .message, _
                                NextErrLine _
                            ), _
                        Env _
                    )
                ElseIf cApp.RunMode = myRunMode.Rate Then
                    ws.GetData( _
                        String.Format( _
                            "INSERT INTO ZEMG_W1LOADERR " & _
                            "(LINE,RECORDTYPE,IVNUM,CURDATE,CODE,MESSAGE) " & _
                            "VALUES " & _
                            "({4},'1','{0}',{1},'{2}','{3}')", _
                                CurStr, _
                                DateDiff(DateInterval.Minute, #1/1/1988#, Now).ToString(), _
                                .code, _
                                .message, _
                                NextErrLine _
                            ), _
                        Env _
                    )
                End If
                If Not quiet Then
                    Console.WriteLine( _
                        String.Format( _
                            "Code: {0} Message: {1}", _
                            .code, _
                            .message _
                            ) _
                        )
                End If
            End With
        Next
    End Sub

    Private Function CancelTrade(ByVal TradeID As String, ByVal selcur As String, ByVal selamt As String, ByVal Rate As String, ByVal Msg As String) As Boolean

        Dim ret As Boolean = False
        If Pause > 0 Then
            Dim tio As Integer = 0
            Console.WriteLine("World First TradeID [{0}].", TradeID)
            Console.WriteLine(Msg)
            Dim lastcolour As System.ConsoleColor = Console.ForegroundColor
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("The total cost of this transaction will be {0} {1}.", _
                selcur.ToUpper, selamt _
            )
            Console.ForegroundColor = lastcolour
            Console.WriteLine("")
            Dim tr As Integer = Console.CursorTop
            Console.WriteLine("")
            Console.WriteLine("Do you wish to proceed (Y/N)?")
            Dim pb As Integer = Console.CursorTop
            Console.WriteLine("")
            Dim ex As Integer = Console.CursorTop

            Do              

                Console.SetCursorPosition(0, tr)
                Console.WriteLine("This quote is valid for {0} more seconds.    ", _
                    CInt(Pause - (tio / 10)))

                Console.SetCursorPosition(0, pb)
                Console.WriteLine(Microsoft.VisualBasic.StrDup(CInt((tio / (Pause * 10)) * Console.WindowWidth), "."))

                Thread.Sleep(100)
                tio += 1

            Loop Until tio >= (Pause * 10) Or Console.KeyAvailable

            Console.SetCursorPosition(0, ex)
            If Console.KeyAvailable Then
                If Not (Console.ReadKey(True).Key = ConsoleKey.Y) Then
                    ret = True
                End If
            Else
                ret = True
            End If
            If ret Then
                Console.WriteLine("Transaction Aborted.")
                Thread.Sleep(1000)
            End If
        End If
        Return ret
    End Function

    Private Sub DoConf(ByVal Conf As Dictionary(Of Integer, w1st_RESPONSE_tradeconfirmation))
        For Each cf As w1st_RESPONSE_tradeconfirmation In Conf.Values
            With cf
                If Not ConfExist(.tradeconfirmationid) Then
                    Dim SQL = String.Format("INSERT INTO ZEMG_W1TRADECONF " & _
                        "(SUCCESS , TRADECONFIRMATIONID , SETTLEMENTAMOUNT , SETTLEMENTDATE , SETTLEMENTMETHOD, DEPOSITAMOUNT , DEPOSITDATE , WFACCOUNTNAME , WFACCOUNTCURRENCY , WFACCOUNTADDRESS1 , WFACCOUNTADDRESS2 , WFACCOUNTADDRESS3 , WFBANKNAME , WFBANKADDRESS1 , WFBANKADDRESS2 , WFBANKADDRESS3 , WFIBAN , WFBIC , WFACCOUNTNUMBER , WFBANKCODE) " & _
                        "VALUES ('{0}', '{1}', {2}, {3}, {4}, {5}, '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}')", _
                        "Y", _
                        .tradeconfirmationid, _
                        .settlementamount, _
                        DateDiff(DateInterval.Minute, #1/1/1988#, .settlementdate), _
                        .settlementmethod, _
                        .depositamount, _
                        DateDiff(DateInterval.Minute, #1/1/1988#, .depositdate), _
                        .wfaccountname, _
                        .wfaccountcurrency, _
                        .wfaccountaddress1, _
                        .wfaccountaddress2, _
                        .wfaccountaddress3, _
                        .wfbankname, _
                        .wfbankaddress1, _
                        .wfbankaddress2, _
                        .wfbankaddress3, _
                        .wfiban, _
                        .wfbic, _
                        .wfaccountnumber, _
                        .wfbankcode)

                    ws.GetData(SQL, Env)
                End If
            End With
        Next
    End Sub

    Private Function ConfExist(ByVal ID As String) As Boolean
        Dim sd As New Loading.SerialData
        Dim SQL As String = "SELECT TRADECONFIRMATIONID FROM ZEMG_W1TRADECONF " & _
            "where TRADECONFIRMATIONID = '" & ID & "'"

        Dim cd As New Loading.ColumnDef(SQL)
        With sd
            .FromStr(ws.GetData(SQL, Env))
            If IsNothing(.GetDataError) Then
                If Not IsNothing(.Data) Then
                    Return True
                Else
                    Return False
                End If
            Else
                Throw New Exception(.GetDataError.Message)
            End If
        End With
    End Function

    Private Function NextErrLine() As String

        Dim sd As New Loading.SerialData
        Dim SQL As String = "SELECT MAX(LINE)+1 FROM ZEMG_W1LOADERR"

        Dim cd As New Loading.ColumnDef(SQL)
        With sd
            .FromStr(ws.GetData(SQL, Env))
            If IsNothing(.GetDataError) Then
                If Not IsNothing(.Data) Then
                    Return sd.Data(0, 0)
                Else
                    Throw New Exception("Next Error Line unavailable.")
                End If
            Else
                Throw New Exception(.GetDataError.Message)
            End If
        End With

    End Function

#Region "Initialisation Functions"

    Private Function initQuote() As w1st_REQUEST_GetQuote
        Dim ret As w1st_REQUEST_GetQuote = Nothing
        Dim sd As New Loading.SerialData

        Dim BUYCUR As String = ""
        Dim SELLCUR As String = ""
        Dim AMOUNT As Double = 0

        Dim SQL As String = "SELECT " & _
            "INVOICES.CUST AS SUP, " & _
            "FCUR.ECODE as SELLCUR, " & _
            "TCUR.ECODE as BUYCUR, " & _
            "INVOICES.TOTPRICE as amount, " & _
            "INVOICES.PAYDATE as paymentdate " & _
            "FROM INVOICES , ACCOUNTS AS FA, ACCOUNTS AS TA, CASH, CURRENCIES AS FCUR, CURRENCIES AS TCUR " & _
            "WHERE FA.ACCOUNT = CASH.ACCOUNT " & _
            "AND TA.ACCOUNT = INVOICES.ACCOUNT " & _
            "AND INVOICES.CASH = CASH.CASH " & _
            "AND FA.CURRENCY = FCUR.CURRENCY " & _
            "AND TA.CURRENCY = TCUR.CURRENCY " & _
            "AND INVOICES.IVNUM = '" & IVNum.ToUpper & "' " & _
            "AND INVOICES.TYPE = 'Q'"

        Dim cd As New Loading.ColumnDef(SQL)
        With sd
            .FromStr(ws.GetData(SQL, Env))
            If IsNothing(.GetDataError) Then
                If Not IsNothing(.Data) Then
                    SUP = .Data(cd("SUP"), 0)
                    SELLCUR = .Data(cd("SELLCUR"), 0)
                    BUYCUR = .Data(cd("BUYCUR"), 0)
                    PAYDATE = DateAdd(DateInterval.Minute, CInt(.Data(cd("paymentdate"), 0)), #1/1/1988#).ToString()
                    AMOUNT = CDbl(.Data(cd("amount"), 0))
                Else
                    Throw New Exception("Invalid invoice [" & IVNum & "]")
                End If

            Else
                Throw New Exception(.GetDataError.Message)
            End If
        End With

        Return New w1st_REQUEST_GetQuote( _
            PAYDATE, _
            BUYCUR, _
            SELLCUR, _
            w1st_enum_Side.B, _
            AMOUNT _
        )

    End Function

    Private Function initRateQuote() As w1st_REQUEST_GetQuote

        Dim pd As String = Nothing
        Dim sd As New Loading.SerialData
        Dim SELLCUR As String = ""
        Dim SQL As String = "SELECT CODE FROM CURRENCIES WHERE POS = 1"

        Dim cd As New Loading.ColumnDef(SQL)
        With sd
            .FromStr(ws.GetData(SQL, Env))
            If IsNothing(.GetDataError) Then
                If Not IsNothing(.Data) Then
                    SELLCUR = .Data(cd("CODE"), 0)
                Else
                    Throw New Exception("Invalid invoice [" & IVNum & "]")
                End If

            Else
                Throw New Exception(.GetDataError.Message)
            End If
        End With

        Select Case Date.Now.DayOfWeek
            Case 5
                pd = DateAdd(DateInterval.Day, 3, Date.Now).ToString()
            Case 6
                pd = DateAdd(DateInterval.Day, 2, Date.Now).ToString()
            Case Else
                pd = DateAdd(DateInterval.Day, 1, Date.Now).ToString()
        End Select

        Return New w1st_REQUEST_GetQuote( _
            pd, _
            CurStr, _
            SELLCUR, _
            w1st_enum_Side.S, _
            1.0 _
        )
    End Function

    Private Function initService() As w1st_Service
        Dim ret As w1st_Service = Nothing
        Dim sd As New Loading.SerialData
        With sd
            .FromStr(ws.GetData( _
                "SELECT W1URL, W1USER, W1PASS, W1STKEY " & _
                "FROM COMPDATA " & _
                "WHERE COMP <> 0" _
            , Env))
            If IsNothing(.GetDataError) Then
                ret = New w1st_Service( _
                    .Data(0, 0), _
                    .Data(1, 0), _
                    .Data(2, 0), _
                    .Data(3, 0) _
                )
            Else
                Throw New Exception(.GetDataError.Message)
            End If
        End With
        Return ret
    End Function

    Private Function initPayment(ByVal TradeID As String) As w1st_REQUEST_Payment()

        Dim ret() As w1st_REQUEST_Payment = Nothing
        Dim sd As New Loading.SerialData
        Dim SQL As String = "SELECT      " & _
            "dbo.FNCITEMSA.FNCIREF2 AS paymentid,  " & _
            "dbo.INVOICES.TOTPRICE AS amount,  " & _
            "dbo.FNCITEMSA.IV AS IV,  " & _
            "dbo.FNCITEMSA.KLINE AS KLINE,  " & _
            "dbo.FNCITEMSA.FNCTRANS AS FNCTRANS " & _
            "FROM         dbo.CUSTOMERS RIGHT OUTER JOIN " & _
            "                      dbo.FNCITEMSB RIGHT OUTER JOIN " & _
            "                      dbo.IVTYPES INNER JOIN " & _
            "                      dbo.ACCOUNTS INNER JOIN " & _
            "                      dbo.FNCITEMS ON dbo.ACCOUNTS.ACCOUNT = dbo.FNCITEMS.ACCOUNT INNER JOIN " & _
            "                      dbo.FNCITEMSA INNER JOIN " & _
            "                      dbo.FNCICODES ON dbo.FNCITEMSA.FNCIC = dbo.FNCICODES.FNCIC ON dbo.FNCITEMS.FNCTRANS = dbo.FNCITEMSA.FNCTRANS AND " & _
            "                      dbo.FNCITEMS.KLINE = dbo.FNCITEMSA.KLINE INNER JOIN " & _
            "                      dbo.INVOICES ON dbo.FNCITEMSA.IV = dbo.INVOICES.IV ON dbo.IVTYPES.DEBIT = dbo.INVOICES.DEBIT AND  " & _
            "                      dbo.IVTYPES.TYPE = dbo.INVOICES.TYPE ON dbo.FNCITEMSB.FNCTRANS = dbo.FNCITEMS.FNCTRANS AND  " & _
            "                      dbo.FNCITEMSB.KLINE = dbo.FNCITEMS.KLINE LEFT OUTER JOIN " & _
            "                      dbo.ACCOUNTS AS ACCOUNTS1 RIGHT OUTER JOIN " & _
            "                      dbo.LOADFNCIDEF ON ACCOUNTS1.ACCOUNT = dbo.LOADFNCIDEF.PDACCOUNT ON dbo.FNCITEMS.FNCTRANS = dbo.LOADFNCIDEF.FNCTRANS AND  " & _
            "                      dbo.FNCITEMS.KLINE = dbo.LOADFNCIDEF.KLINE ON dbo.FNCITEMSB.CUST = dbo.CUSTOMERS.CUST " & _
            "                       WHERE     (dbo.FNCITEMS.QIV = " & _
            "                          (SELECT     IV " & _
            "                            FROM          dbo.INVOICES AS INVOICES_1 " & _
            "                            WHERE      (IVNUM = '" & IVNum.ToUpper & "')))"

        Dim cd As New Loading.ColumnDef(SQL)
        With sd
            .FromStr(ws.GetData(SQL, Env))
            If IsNothing(.GetDataError) Then
                If Not IsNothing(.Data) Then
                    Dim bene As w1st_REQUEST_Beneficiary = initBenificiary()
                    For y As Integer = 0 To UBound(.Data, 2)
                        Try
                            ReDim Preserve ret(UBound(ret) + 1)
                        Catch ex As Exception
                            ReDim ret(0)
                        Finally
                            PR.Add( _
                                .Data(cd("paymentid"), y), _
                                New PayRef( _
                                    .Data(cd("IV"), y), _
                                    .Data(cd("KLINE"), y), _
                                    .Data(cd("FNCTRANS"), y) _
                                ) _
                            )
                            ret(UBound(ret)) = New w1st_REQUEST_Payment( _
                                bene, _
                                 .Data(cd("paymentid"), y), _
                                CDbl(.Data(cd("amount"), y)), _
                                PAYDATE, _
                                w1st_enum_Reason.Paying_Overseas_Suppliers, _
                                TradeID _
                            )
                        End Try
                    Next
                Else
                    Throw New Exception("Invalid invoice [" & IVNum & "]")
                End If

                Return ret
            Else
                Throw New Exception(.GetDataError.Message)
            End If
            Return ret
        End With
    End Function

    Private Function initBenificiary() As w1st_REQUEST_Beneficiary

        Dim ret As w1st_REQUEST_Beneficiary = Nothing
        Dim sd As New Loading.SerialData
        Dim SQL As String = "SELECT " & _
                            "ACCOUNTS.ACCNAME as accname, " & _
                            "SUPDES as name, " & _
                            "SUPPLIERS.ADDRESS as accholderadd1, " & _
                            "SUPPLIERS.STATE as accholderadd2, " & _
                            "SUPPLIERS.ZIP as accholderadd3, " & _
                            "CUR.CODE as curr, " & _
                            "BANKNAME as bankname, " & _
                            "ACCOUNTBANK.BRANCH as bankcode, " & _
                            "PAYACCOUNT as accno, " & _
                            "ACCOUNTBANK.ADDRESS as bankadd1, " & _
                            "ACCOUNTBANK.STATE as bankadd2, " & _
                            "ACCOUNTBANK.ZIP as bankadd3, " & _
                            "BCO.COUNTRYCODE as bankcountry, " & _
                            "BIC as bic " & _
                            "FROM SUPPLIERS , " & _
                            "COUNTRIES CO, " & _
                            "COUNTRIES BCO, " & _
                            "CURRENCIES CUR, " & _
                            "ACCOUNTBANK, " & _
                            "BANKS, " & _
                            "ACCOUNTS " & _
                            "WHERE SUP = " & SUP & _
                            "AND SUPPLIERS.INVACCOUNT = ACCOUNTS.ACCOUNT " & _
                            "AND CO.COUNTRY = SUPPLIERS.COUNTRY " & _
                            "AND BCO.COUNTRY = ACCOUNTBANK.COUNTRY " & _
                            "AND CUR.CURRENCY = SUPPLIERS.CURRENCY " & _
                            "AND ACCOUNTBANK.ACCOUNT = SUPPLIERS.ACCOUNT " & _
                            "AND BANKS.BANK = ACCOUNTBANK.BANK"

        Dim cd As New Loading.ColumnDef(SQL)

        With sd
            .FromStr(ws.GetData(SQL, Env))
            If IsNothing(.GetDataError) Then
                If Not IsNothing(.Data) Then

                    Dim m As Match = Regex.Match( _
                            .Data(cd("accno"), 0), _
                             "[a-zA-Z]{2}[0-9]{2}[a-zA-Z0-9]{4}[0-9]{7}([a-zA-Z0-9]?){0,16}", _
                             RegexOptions.IgnoreCase)

                    Select Case m.Success
                        Case True
                            ret = New w1st_REQUEST_Beneficiary( _
                                                .Data(cd("name"), 0), _
                                                .Data(cd("accholderadd1"), 0), _
                                                .Data(cd("curr"), 0), _
                                                .Data(cd("bankname"), 0), _
                                                .Data(cd("bankcountry"), 0), _
                                                .Data(cd("bankcode"), 0), _
                                                , _
                                                .Data(cd("accno"), 0), _
                                                .Data(cd("bic"), 0), _
                                                .Data(cd("accholderadd2"), 0), _
                                                .Data(cd("accholderadd3"), 0), _
                                                .Data(cd("bankadd1"), 0), _
                                                .Data(cd("bankadd2"), 0), _
                                                .Data(cd("bankadd3"), 0) _
                                            )
                        Case Else
                            ret = New w1st_REQUEST_Beneficiary( _
                                                .Data(cd("name"), 0), _
                                                .Data(cd("accholderadd1"), 0), _
                                                .Data(cd("curr"), 0), _
                                                .Data(cd("bankname"), 0), _
                                                .Data(cd("bankcountry"), 0), _
                                                .Data(cd("bankcode"), 0), _
                                                .Data(cd("accno"), 0), _
                                                , _
                                                .Data(cd("bic"), 0), _
                                                .Data(cd("accholderadd2"), 0), _
                                                .Data(cd("accholderadd3"), 0), _
                                                .Data(cd("bankadd1"), 0), _
                                                .Data(cd("bankadd2"), 0), _
                                                .Data(cd("bankadd3"), 0) _
                                            )
                    End Select
                Else
                    Throw New Exception("Invalid vendor [" & SUP & "]")
                End If
            Else
                Throw New Exception(.GetDataError.Message)
            End If
            Return ret
        End With
    End Function

#End Region

End Module
