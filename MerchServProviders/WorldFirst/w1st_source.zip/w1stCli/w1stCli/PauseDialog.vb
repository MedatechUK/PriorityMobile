Imports System.Windows.Forms
Imports vb = Microsoft.VisualBasic

Public Class PauseDialog

    Private Counter As Integer

#Region "properties"

    Private _Duration As Integer = 20
    Public Property Duration() As Integer
        Get
            Return _Duration
        End Get
        Set(ByVal value As Integer)
            _Duration = value
        End Set
    End Property

    Private _quote As String = ""
    Public Property Quote() As String
        Get
            Return _quote
        End Get
        Set(ByVal value As String)
            _quote = value
        End Set
    End Property

    Private _rate As String = ""
    Public Property rate() As String
        Get
            Return _rate
        End Get
        Set(ByVal value As String)
            _rate = value
        End Set
    End Property

    Private _rrate As String = ""
    Public Property rrate() As String
        Get
            Return _rrate
        End Get
        Set(ByVal value As String)
            _rrate = value
        End Set
    End Property

    Private _ratedate As String = ""
    Public Property ratedate() As String
        Get
            Return _ratedate
        End Get
        Set(ByVal value As String)
            _ratedate = value
        End Set
    End Property

    Private _buycur As String = ""
    Public Property buycur() As String
        Get
            Return _buycur.ToUpper
        End Get
        Set(ByVal value As String)
            _buycur = value.ToUpper
        End Set
    End Property

    Private _sellcur As String = ""
    Public Property sellcur() As String
        Get
            Return _sellcur.ToUpper
        End Get
        Set(ByVal value As String)
            _sellcur = value.ToUpper
        End Set
    End Property

    Private _selamt As String = ""
    Public Property selamt() As String
        Get
            Return _selamt
        End Get
        Set(ByVal value As String)
            _selamt = value
        End Set
    End Property

#End Region

    Public Sub Draw()
        With Me
            .lbl_quote.Text = Me.Quote
            .lbl_ratedate.Text = String.Format("@ {0}", .ratedate)
            .lbl_rate.Text = String.Format("{0} 1 = {1} {2}", .sellcur, .rate, .buycur)
            .lbl_rrate.Text = String.Format("{0} 1 = {1} {2}", .buycur, .rrate, .sellcur)
            .lbl_selamt.Text = String.Format("The total cost of this transaction will be {0} {1}.", .sellcur, .selamt)

            .Counter = .Duration

            .ProgressBar1.ForeColor = Drawing.Color.Blue
            .ProgressBar1.Maximum = .Duration
            .ProgressBar1.Value = .Duration

            setLabels()

            .Timer.Enabled = True

        End With
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub Timer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer.Tick
        If Counter > -1 Then
            setLabels()
        Else
            Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.Close()
        End If
    End Sub

    Private Sub setLabels()

        Me.ProgressBar1.Value = Counter
        Dim w As Integer = Counter
        Dim min As Integer = 0
        Do While (w - 60) >= 0
            min += 1
            w -= 60
        Loop

        Me.OK_Button.Text = String.Format("Proceed ({0}:{1})", _
            vb.Right("00" & min.ToString, 2), _
            vb.Right("00" & w.ToString, 2) _
            )

        Counter -= 1

        If ((Counter / Duration) * 100) < 10 Then
            Me.ProgressBar1.ForeColor = Drawing.Color.Red
        End If
    End Sub

End Class
