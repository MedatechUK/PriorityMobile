Class Program

    Shared Sub Main(ByVal args() As String)

        Dim w1svc As New w1st_Service( _
             "https://trading.worldfirst.com/api/demo/", _
            "demo", _
            "d3m0u5r", _
            "abcdefghihjklmnopqrstuvwxyz0123456789" _
        )

        With w1svc
            .request = New w1st_REQUEST(False, True, )
            With .request

                With .GetQuote ' Request a quote
                    .Add(.Count + 1, _
                    New w1st_REQUEST_GetQuote( _
                        Now.AddDays(1), ISO4217.EU_euro, _
                        ISO4217.British_pound, w1st_enum_Side.B, 100.0 _
                        ) _
                    )
                End With

                With .Payment ' Request a payment
                    .Add(.Count + 1, _
                    New w1st_REQUEST_Payment( _
                        New w1st_REQUEST_Beneficiary( _
                            "Customer", "Address", ISO4217.EU_euro, _
                            "Your Bank", ISO3166.SPAIN, "13-24-56", _
                            "11112222", "ES9121000418450200051332", "WFSTGB01", , , _
                            "999 lombard street", "Barcelona", _
                        ), _
                        "1234", 100, Now.AddDays(1), _
                        w1st_enum_PaymentType.SEPA, _
                        w1st_enum_Reason.Overseas_Purchase, _
                        "nontrade_payment1", _
                        ISO4217.British_pound, ) _
                    )
                End With

                '.PastPaymentid = "12345" ' Request payment info

            End With

            ' Display the request
            Console.WriteLine("Request------------------------------------")
            Console.WriteLine(String.Format("XML: {0}", .RequestXML))
            Console.WriteLine(String.Format("Hash: {0}", .Hash))

            Try
                ' Send the request to popluate the response object
                .Send()

                If Not IsNothing(.response) Then
                    With .response
                        Console.WriteLine("Response------------------------------------")
                        Console.WriteLine(String.Format("Atomic: {0} Testing: {1}", .Atomic, .Testing))

                        ' Iterate through quotes in the response
                        For Each q As w1st_RESPONSE_quote In .Quote.Values
                            With q
                                Console.WriteLine( _
                                    String.Format( _
                                        "success: {0} tradeid: {1} buycurr: {2} " & _
                                        "sellcurr: {3} buyamt: {4} " & _
                                        "sellamt: {5} rate: {6} settlementdate: {7} " & _
                                        "expiry: {8} side: {9} amount: {10}", _
                                            .success, _
                                            .tradeid, _
                                            .buycurr, _
                                            .sellcurr, _
                                            .buyamt, _
                                            .sellamt, _
                                            .rate, _
                                            .settlementdate, _
                                            .expiry, _
                                            .side, _
                                            .amount _
                                        ) _
                                    )
                                ' Iterate quote errors
                                For Each er As w1st_RESPONSE_error In .Errors.Values
                                    With er
                                        Console.WriteLine( _
                                            String.Format( _
                                                "Code: {0} Message: {1}", _
                                                .code, .message _
                                            ) _
                                        )
                                    End With
                                Next
                            End With
                        Next

                        ' Iterate through payments in the response
                        For Each p As w1st_RESPONSE_payment In .Payment.Values
                            With p
                                Console.WriteLine( _
                                    String.Format( _
                                        "success: {0} tradeid: {1} paymentid: {2} " & _
                                        "buycurr: {3} sellcurr: {4} " & _
                                        "amount: {5} rate: {6} paymentdate: {7}", _
                                        .success, _
                                        .tradeid, _
                                        .paymentid, _
                                        .buycurr, _
                                        .sellcurr, _
                                        .amount, _
                                        .rate, _
                                        .paymentdate _
                                        ) _
                                    )
                                ' Iterate payment errors
                                For Each er As w1st_RESPONSE_error In .Errors.Values
                                    With er
                                        Console.WriteLine( _
                                            String.Format( _
                                                "Code: {0} Message: {1}", _
                                                .code, .message _
                                            ) _
                                        )
                                    End With
                                Next
                            End With
                        Next

                        ' Iterate through Past Payments in the response
                        For Each pp As w1st_RESPONSE_PastPayment In .PastPayment.Values
                            With pp
                                Console.WriteLine( _
                                    String.Format( _
                                        "requested-paymentid: {0} success: {1} created: {2} " & _
                                        "tradeid: {3} buycurr: {4} sellcurr: {5} amount: {6} " & _
                                        "rate: {7} paymentdate: {8}", _
                                            .requested_paymentid, _
                                            .success, _
                                            .created, _
                                            .tradeid, _
                                            .buycurr, _
                                            .sellcurr, _
                                            .amount, _
                                            .rate, _
                                            .paymentdate _
                                        ) _
                                    )
                                ' Iterate past payment errors
                                For Each er As w1st_RESPONSE_error In .Errors.Values
                                    With er
                                        Console.WriteLine( _
                                            String.Format( _
                                                "Code: {0} Message: {1}", _
                                                .code, .message _
                                            ) _
                                        )
                                    End With
                                Next
                            End With
                        Next

                        ' Iterate top level errors
                        For Each er As w1st_RESPONSE_error In .Errors.Values
                            With er
                                Console.WriteLine( _
                                    String.Format( _
                                        "Code: {0} Message: {1}", _
                                        .code, .message _
                                    ) _
                                )
                            End With
                        Next

                    End With
                End If
            Catch ex As Exception
                Console.WriteLine(ex.Message)
            End Try
        End With
        Console.ReadLine()
    End Sub

End Class


