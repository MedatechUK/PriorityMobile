Public Class PayRef
    Public Sub New()
        MyBase.new()
    End Sub
    Public Sub New(ByVal IV As Integer, ByVal KLINE As Integer, ByVal FNCTRANS As Integer)
        With Me
            .IV = IV
            .KLINE = KLINE
            .FNCTRANS = FNCTRANS
        End With
    End Sub
    Private _IV As Integer = Nothing
    Public Property IV() As Integer
        Get
            Return _IV
        End Get
        Set(ByVal value As Integer)
            _IV = value
        End Set
    End Property
    Private _KLINE As Integer = Nothing
    Public Property KLINE() As Integer
        Get
            Return _KLINE
        End Get
        Set(ByVal value As Integer)
            _KLINE = value
        End Set
    End Property
    Private _FNCTRANS As Integer
    Public Property FNCTRANS() As Integer
        Get
            Return _FNCTRANS
        End Get
        Set(ByVal value As Integer)
            _FNCTRANS = value
        End Set
    End Property
    Private _TradeID As String
    Public Property TradeID() As String
        Get
            Return _TradeID
        End Get
        Set(ByVal value As String)
            _TradeID = value
        End Set
    End Property
    Private _rate As Double
    Public Property Rate() As Double
        Get
            Return _rate
        End Get
        Set(ByVal value As Double)
            _rate = value
        End Set
    End Property
    Private _HasResponse As Boolean = False
    Public Property HasResponse() As Boolean
        Get
            Return _HasResponse
        End Get
        Set(ByVal value As Boolean)
            _HasResponse = value
        End Set
    End Property
End Class
